---
name: task-creator
description: Convert brain dumps, ideas, or new thoughts into actionable tasks with proper linking to Brain Dumps, Areas of Interest, and Key Results.
---

# Task Creator Skill

## When to Use This Skill
- User says: "make this a task", "create task", "add to tasks", "turn this into a task"
- User describes something actionable
- User is processing brain dumps and decides something is a task
- User wants to link a task to an OKR or area

## Technical Implementation

### Database Information
- Tasks Data Source: `collection://2eb845ad-210e-805d-87ff-000b057cec59`
- Brain Dump Data Source: `collection://2ec845ad-210e-80af-bfbb-000ba4f0fa08`
- Areas Data Source: `collection://2eb845ad-210e-800f-8772-000b3904e895`
- Key Results Data Source: `collection://2f3845ad-210e-80c9-9b76-000b5de37695`

### Required Fields
- **Task Name** (title): The action to be taken
- **Status**: Default to "To Do"
- **Created Date**: ALWAYS set to today's date

### Optional Fields
- **Priority**: High, Medium (default), Low
- **Due Date**: When it needs to be done
- **Description**: Additional context
- **Tags**: Infer from content
- **Related Brain Dump, Area, Key Result**: Link as appropriate

## Interaction Patterns

### Simple Task
**User**: "Create task: Update LinkedIn with certification"
**Action**: Create task with tags, Created Date
**Response**: "Created task: Update LinkedIn with certification"

### From Brain Dump
**User**: "Turn my brain dump about CRAFT library into a task"
**Action**: Search brain dump, create task, link them, update brain dump status
**Response**: "Created task and linked to your brain dump."

### With Full Details
**User**: "Create task: Draft Q1 review. Due next Friday. High priority."
**Action**: Create with all details including Created Date
**Response**: "Created high-priority task due Jan 31: Draft Q1 review"

### Link to Area/KR
**User**: "Create task to research behavior design. Related to my AI adoption area."
**Action**: Create task, link to area
**Response**: "Created task and linked to AI adoption area."

## Smart Tag Inference
Based on content: Work, AI/Consulting, Personal, Health, Learning, Business Development, Content Creation

## Priority & Date Inference
- **High**: "urgent", "ASAP", "critical", "by Friday"
- **Low**: "someday", "when I have time"  
- **Dates**: "tomorrow", "next Friday", "end of month", "in 2 weeks"

## Created Date Format
- `date:Created Date:start`: "2026-01-25"
- `date:Created Date:is_datetime`: 0

## Response Style
✅ "Created task: [name]"
✅ "Task created and linked to [brain dump/area]."
❌ "I have successfully created a new task entry..."

## Updating Brain Dump After Task Creation
When converting brain dump to task:
1. Update Brain Dump: Status="Processed", Action Taken="Created Task"
2. Link task to brain dump (two-way relation)

**Remember**: Tasks are the "do" part. Make creation fast, linking automatic.
